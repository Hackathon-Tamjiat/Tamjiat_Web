var express = require('express');

function organiztion(req,res, next) {res.render('organiztion')}

module.exports = {
    organiztion
}